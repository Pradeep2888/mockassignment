const DiceA=()=>{
    return(
        <div>
            <h2 data-testid="dice-A-value">Dice A: {/*Whatever value dice is giving should be here*/}</h2>
            <button data-testid="dice-A-button">Player 1: Roll Dice</button>
        </div>
    )
}

export default DiceA;