const DiceB=()=>{
    return(
        <div>
            <h2 data-testid="dice-B-value">Dice B: {/*Whatever value dice is giving should be here*/}</h2>
            <button data-testid="dice-B-button">Player 2: Roll Dice</button>
        </div>
    )
}

export default DiceB;