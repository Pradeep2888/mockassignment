import { useEffect, useState } from "react";
// import "./App.css";
import UserDetails from "./components/UserDetails";
import data from "./db.json"

function App() {
 const [avatar,setAvatar]=useState(data)
 const [short,setShort]=useState("Asc")
 const handelAvatar=()=>{
  if(short==="Asc"){
    data.sort((a, b) => {
      const nameA = a.first_name.toUpperCase(); // ignore upper and lowercase
      const nameB = b.first_name.toUpperCase(); // ignore upper and lowercase
      if (nameA < nameB) {
        return -1;
      }
      if (nameA > nameB) {
        return 1;
      }
    
      // names must be equal
      return 0;
    })
  }
  else if(short==="Dsc"){
    data.sort((a, b) => {
      const nameA = a.first_name.toUpperCase(); // ignore upper and lowercase
      const nameB = b.first_name.toUpperCase(); // ignore upper and lowercase
      if (nameA > nameB) {
        return -1;
      }
      if (nameA < nameB) {
        return 1;
      }
    
      // names must be equal
      return 0;
    })
    // setAvatar(data)
  }
  
 }
 handelAvatar()
// useEffect(()=>{
  

// },[short])
  
// console.log(short)
 

  return (
    <div className="App" data-testid = 'app'>
      <button onClick={()=>setShort("Asc")}  data-testid = 'sort-asc-btn'>Sort by Asc</button>
      <button onClick={()=>setShort("Dsc")} data-testid = 'sort-desc-btn'>Sort by Desc</button>
      {data.map((item)=>(
        <UserDetails key={item.id} id={item.id} avatar={item.avatar} address={item.address} first_name={item.first_name} followers={item.followers} is_following={item.is_following} karma={item.karma} last_name={item.last_name} posts={item.posts} />
      ))}
    </div>
  );
}

export default App;
