import {navbar,slidebar} from "./navbar.js"
let n=document.getElementById("navbar")
let s=document.getElementById("slide")

n.innerHTML=navbar()
s.innerHTML=slidebar()



function appenduser(){
    let userData=JSON.parse(localStorage.getItem("user"))
    // console.log(userData[0])

    userData.forEach(function(el){
        let i=document.getElementById("user_img")
        i.src=el.image
        let n=document.getElementById("user_name")
        n.innerText=el.name
        let e=document.getElementById("user_email")
        e.innerText=el.email
        let c=document.getElementById("user_country")
        c.innerText=el.country
    })
}
appenduser()


async function worldnews(){

    let country=JSON.parse(localStorage.getItem("user"))
    let countrycode=country[0].country

   
    
let url=`https://masai-mock-api.herokuapp.com/news/top-headlines?country=${countrycode}`

try{
 let res= await fetch(url)
 let data=await res.json()
 append(data.articles)
}
catch(err){
    console.log(err)
}

}
worldnews()


function append(data){
    // console.log(data)
    data.forEach(function(el){
        let container=document.getElementById("news_result")

        let card=document.createElement("div")
        card.setAttribute("class","news")
        let image=document.createElement("img")
        image.src=el.urlToImage
        let title=document.createElement("p")
        title.innerText=el.title
        let author=document.createElement("p")
        author.innerText=el.author

        card.append(image,title,author)

        container.append(card)
        
    })
}


let categories=document.getElementById("categories").children
for (let el of categories){
    el.addEventListener("click",cSearch)
}
async function cSearch(){
    let countrycode=this.id
        
let url=`https://masai-mock-api.herokuapp.com/news/top-headlines?country=${countrycode}`

try{
 let res= await fetch(url)
 let data=await res.json()
 let container=document.getElementById("news_result")
 container.innerHTML=null
 append(data.articles)
}
catch(err){
    console.log(err)
}
}



document.getElementById("query").addEventListener("keydown",search)

async function search(e){
if(e.key==="Enter"){
    let value=document.getElementById("query").value
    // console.log(value)
    let url=`https://masai-mock-api.herokuapp.com/news?q=${value}`
    try{
       let res= await fetch(url) 
       let data= await res.json()
        let container=document.getElementById("news_result")
       container.innerHTML=null
       append(data.articles)
    }
    catch (err){
console.log(err)
    }

}
}