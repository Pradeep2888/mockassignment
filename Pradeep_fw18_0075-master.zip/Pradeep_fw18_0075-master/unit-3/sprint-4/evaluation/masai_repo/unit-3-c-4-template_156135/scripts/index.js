/*
Save the user to local storage with key "user", in following format:- 
{
name: "",
image: "",
email: "",
country: "" (store country code "in", "ch", "nz", "us", "uk")
}
*/
document.getElementById("submit").addEventListener("click",userdetail)

function userdetail(){
    let arr=JSON.parse(localStorage.getItem("user"))||[]
    let i=document.getElementById("user_pic").value
    let n=document.getElementById("user_name").value
    let e=document.getElementById("user_email").value
    let c=document.getElementById("user_country").value
    let obj={
        name:n,
        image:i,
        email:e,
        country:c,

    }
    arr.push(obj)
    localStorage.setItem("user",JSON.stringify(arr))

    // console.log(name,email,country)
}