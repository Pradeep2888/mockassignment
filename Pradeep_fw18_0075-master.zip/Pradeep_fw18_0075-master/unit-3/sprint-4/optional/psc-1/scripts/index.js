// link:https://api.unsplash.com/search/photos/?query=${cat}&per_page=20client_id=YOUR_ACCESS_KEY
// GET /search/photos
// API:https://api.unsplash.com/search/photos/?query=cat&per_page=20&client_id=0nQadOR6-lGp8BcE53R1KtT7aNxVovi3xSH1wnJPvMQ

import {navbar} from "../components/navbar.js"
let n =document.getElementById('navbar')
n.innerHTML=navbar();

import {searchImages,append} from "../scripts/fetch.js"

let search=(e)=>{
    if(e.key==="Enter"){
        let value=document.getElementById("query").value
        searchImages(value).then((data)=>{
            let container=document.getElementById("container")
            // console.log(data)
            container.innerHTML=null
            append(data.results,container)
        })
       
    }
    
}

document.getElementById("query").addEventListener("keydown",search);

let categories=document.getElementById("categories").children
// console.log(categories)



function cSearch(){
  console.log(this.id)
  searchImages(this.id).then((data)=>{
    let container=document.getElementById("container")
    // console.log(data)
    container.innerHTML=null
    append(data.results,container)
})
}


for(let el of categories){
    el.addEventListener("click",cSearch)
}


// h3={
//     id:"nature"
//     cSearch()
// }
// let searchImages=async ()=>{
//     let value=document.getElementById("query").value
   
//     // let url=

//     try{
//         let res= await fetch(`https://api.unsplash.com/search/photos/?query=${value}&per_page=20&client_id=0nQadOR6-lGp8BcE53R1KtT7aNxVovi3xSH1wnJPvMQ`)
//         let data=await res.json()
//         console.log(data)

//     }
//     catch(err){
//         console.log(err)
//     }
// }