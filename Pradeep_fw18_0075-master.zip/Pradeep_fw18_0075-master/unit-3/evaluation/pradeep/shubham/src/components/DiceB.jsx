const DiceB=({player,handelClick2,handelPlayer,count2,score2})=>{
    return(
        <div>
            <h2 data-testid="dice-B-value">Dice B: {/*Whatever value dice is giving should be here*/}</h2>
            <button data-testid="dice-B-button" disabled={player===true || count2===6} onClick={()=>{handelClick2();handelPlayer()}}>Player 2: Roll Dice</button>
        </div>
    )
}

export default DiceB;