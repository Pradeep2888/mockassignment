import React from 'react'
import { Route, Routes } from 'react-router-dom'
import AddProduct from '../Componets/AddProduct'
import BookMark from '../Componets/BookMark'
import Dashboard from '../Componets/Dashboard'

function AllRoute() {
  return (
    <div>
        <Routes>
            <Route path='/' element={<Dashboard/>} />
            <Route path='/bookmark' element={<BookMark/>} />
            <Route path='/addproduct' element={<AddProduct/>} />
        </Routes>
    </div>
  )
}

export default AllRoute