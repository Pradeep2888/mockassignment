import { Button } from '@chakra-ui/react'
import axios from 'axios'
import React from 'react'

function ProductCard({id,quantity,discription,title,priority,time}) {

    const handelBookmark=(id)=>{
        console.log(id)
        axios.post(`http://localhost:8080/product/createbookmark`,{
            id:id
        })
        .then((r)=>{
            alert("Item Bookmarked")
        })
        .catch((e)=>{
            console.log(e)
        })
    }

    const handelDelete=(id)=>{
        axios.delete(`http://localhost:8080/product/delete/${id}`)
        .then((r)=>{
            alert("Item deleted")
            window.location.reload()
        })
        .catch((e)=>{
            console.log(e)
        })
    }

   
  return (
    <div id='card'>
        <h1>{title}</h1>
        <h3>{quantity}</h3>
        <h3>{priority}</h3>
        <h6>{time}</h6>
        <p>{discription}</p>
        <Button onClick={()=>handelBookmark(id)} >Bookmark</Button>
        <Button onClick={()=>handelDelete(id)} >Delete</Button>
        
    </div>
  )
}

export default ProductCard