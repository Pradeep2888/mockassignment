import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import ProductCard from './ProductCard'

function Dashboard() {
    const [data,setData]=useState([])
    const getData=()=>{

        axios.get("http://localhost:8080/product")
        .then((r)=>{
            console.log(r.data.data)
            setData(r.data.data)
        })
        .catch((e)=>{
            console.log(e)
        })
    }

    const [p,setP]=useState(0)

    const handelChange=(e)=>{
        setP(e.target.value)
    }
   


    useEffect(()=>{
        getData(p)
    },[p])

  return (
    <div>
        <div>
        <Link to="/addproduct" >Add Product</Link>
        <Link to="/bookmark" >Book Mark</Link>
        </div>

        <div>
            <select onChange={(e)=>handelChange(e)} >
                <option value={0} >Select Priority</option>
                <option value={1}>1</option>
                <option value={2}>2</option>
                <option value={3}>3</option>
                <option value={4}>4</option>
                <option value={5}>5</option>
            </select>
        </div>
       

       <div id='productArea' >
          {
            data.map((item)=>(
                <ProductCard key={item._id} quantity={item.quantity} priority={item.priority} discription={item.discription} title={item.title} id={item._id} time={item.updatedAt}   />
            ))
          }
       </div>

    </div>
  )
}

export default Dashboard