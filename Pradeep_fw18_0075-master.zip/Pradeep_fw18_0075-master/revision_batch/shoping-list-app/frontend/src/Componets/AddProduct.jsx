import { FormControl, Input } from '@chakra-ui/react'
import axios from 'axios'
import React from 'react'

function AddProduct() {
    const handelAdd=(e)=>{
      e.preventDefault()
      let title=document.querySelector(".tilte").value
      let quantity=document.querySelector(".quantity").value
      let priority=document.querySelector(".priority").value
      let discription=document.querySelector(".discription").value
       
      const obj={
        title,
        quantity,
        priority,
        discription
      }
      
      postData(obj)

    }

    const postData=(obj)=>{
        
        axios.post('http://localhost:8080/product/addproduct',obj)
          .then(function (response) {
           alert("Product Added")
          })
          .catch(function (error) {
            alert("Something went wrong!")
          });
    }



  return (
    <div>
        <form onSubmit={(e)=>handelAdd(e)} >
            <Input type={"text"} placeholder='Title of Item' className='tilte' />
            <Input type="number" min={0} max={10}  placeholder='Quantity' className='quantity' />
            <Input type="number" min={0} max={10} placeholder='Priority' className='priority'  />
            <Input type="text" placeholder='Description' className='discription' />
            <Input type="submit" value={"Add Product"}  />
        </form>
    </div>
  )
}

export default AddProduct