import { Button } from '@chakra-ui/react'
import axios from 'axios'
import React, { useEffect, useState } from 'react'

function BookMark() {


    const [data,setData]=useState([])
    const getData=()=>{

        axios.get("http://localhost:8080/product/bookmark")
        .then((r)=>{
            console.log(r.data.data)
            setData(r.data.data)
        })
        .catch((e)=>{
            console.log(e)
        })
    }


    const handelDelete=(id)=>{
        axios.delete(`http://localhost:8080/product/bookmarkdelete/${id}`)
        .then((r)=>{
            alert("Item deleted")
            getData()
        })
        .catch((e)=>{
            console.log(e)
        })
    }


    useEffect(()=>{
        getData()
    },[])

  return (
    <div>
        {
            data.map((item)=>{
                return (
                    <div key={item._id} >
                    <h1>{item.title}</h1>
                 <h3>{item.quantity}</h3>
                  <h3>{item.priority}</h3>
                 <p>{item.discription}</p>
                 <Button onClick={()=>handelDelete(item._id)} >Delete</Button>
                </div>
                )
            })
        }
    </div>
  )
}

export default BookMark