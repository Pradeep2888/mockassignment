import logo from './logo.svg';
import './App.css';

import AllRote from './Routes/AllRote';

function App() {
  return (
    <div className="App">
     <AllRote/>
    </div>
  );
}

export default App;
