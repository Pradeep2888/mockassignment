import React from 'react'

function Emi() {
  return (
    <div>Emi</div>
  )
}

export default Emi