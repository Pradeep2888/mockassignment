import { Alert, Button, Input } from '@mui/material'
import React from 'react'
import { useState } from 'react'
import { useNavigate } from 'react-router-dom'

function Signup() {
  const navigate=useNavigate()
    const [name,setName]=useState("")
    const [email,setEmail]=useState("")
    const [password,setPassword]=useState("")
    const handleSubmit=()=>{
        const payload={
            name,
            email,
            password
        }
        fetch("https://modsons.onrender.com/signup",{
        
            headers: {
                'Content-Type': 'application/json'
                
              },
            body: JSON.stringify(payload),
            method: 'POST'


        })
        .then((res)=>res.json())
        .then((res)=>{
         if(res.msg==="Sign up successfull"){
           alert("Sign up successfull")
           navigate("/login")
         }
         else{
          alert("Something went wrong, please try again")
         }
        })
 
    }
  return (
    <div>
        <h1>Signup page</h1>
        <div>
            <Input type="name" placeholder='Name' onChange={(e)=>setName(e.target.value)} />
            <Input type="email" placeholder='Email' onChange={(e)=>setEmail(e.target.value)} />
            <Input type="password" placeholder='Password' onChange={(e)=>setPassword(e.target.value)} />
            <Button variant="contained" onClick={handleSubmit} >Submit</Button>
        </div>
    </div>
  )
}

export default Signup