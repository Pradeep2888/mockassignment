import { Button, Input } from '@mui/material'
import React, { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'

function Login() {
  const navigate=useNavigate()
    const [email,setEmail]=useState("")
    const [password,setPassword]=useState("")
    const handleSubmit=()=>{
        const payload={
            email,
            password
        }
        fetch("https://modsons.onrender.com/login",{
        
            headers: {
                'Content-Type': 'application/json'
                
              },
            body: JSON.stringify(payload),
            method: 'POST'


        })
        .then((res)=>res.json())
        .then((res)=>{
          if(res.message==="Login successfull"){
            localStorage.setItem("token",JSON.stringify(res.token))
            alert("login sucessfully")
            navigate("/")
          }
          else{
            alert("something went wrong Try Again")
          }
        })
    }
  return (
    <div>
        <h1>Login page</h1>
        <div>
            <Input type="email" placeholder='Email' onChange={(e)=>setEmail(e.target.value)} />
            <Input type="password" placeholder='Password' onChange={(e)=>setPassword(e.target.value)} />
            <Button onClick={handleSubmit} >Login</Button>
            <Button><Link to={"/"} >Go to signup</Link></Button>
        </div>
    </div>
  )
}

export default Login