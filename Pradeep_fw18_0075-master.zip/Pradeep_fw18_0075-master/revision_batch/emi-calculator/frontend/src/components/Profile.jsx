import axios from 'axios'
import React from 'react'

function Profile() {

  const getData=async()=>{
    let token=JSON.parse(localStorage.getItem("token"))
    token="token"+" "+token
    
    axios.get("https://modsons.onrender.com/getProfile", { headers: {"Authorization" : `Bearer ${token}`} })
    .then((res)=>{
      console.log(res)
    })
  }

  getData()

  return (
    <div>
<h1>h</h1>
    </div>
  )
}

export default Profile