import { Button } from '@mui/material'
import React from 'react'
import { Link } from 'react-router-dom'

function Dashboard() {
  return (
    <div>
         <Button><Link to={"/profile"} >Go to Profile</Link></Button>
         <Button><Link to={"/emi"} >Go to EMI</Link></Button>
    </div>
  )
}

export default Dashboard