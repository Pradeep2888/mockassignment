import React from 'react'
import { Route, Router, Routes } from 'react-router-dom';
import Login from '../components/Login';
import Signup from '../components/Signup';
import Profile from '../components/Profile';
import Emi from '../components/Emi';
import Dashboard from '../components/Dashboard';
function AllRote() {
  return (
    <div>
        <Routes>
      <Route path="/login" element={<Login/>} />
      <Route path="/" element={<Signup/>} />
      <Route path='/profile' element={<Profile/>} />
      <Route path='/emi' element={<Emi/>} />
     </Routes>
    </div>
  )
}

export default AllRote