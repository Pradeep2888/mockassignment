import axios from "axios"
import { GET_DATA_FAILURE, GET_DATA_REQUEST, GET_DATA_SUCCESS } from "./actionType"


export const getDataRequest=()=>{
    return {
        type:GET_DATA_REQUEST
    }
}

export const getDataSuccess=(payload)=>{
    return {
        type:GET_DATA_SUCCESS,
        payload
    }
}

export const getDataFailure=()=>{
    return {
        type:GET_DATA_FAILURE
    }
}


export const getData=(filter,search,page)=>(dispatch)=>{
    console.log(search,filter,page)
//  if(page===1){   // Request
//       dispatch(getDataRequest())
//       return axios.get(`https://job-test-api.onrender.com/job`).then((r)=>{
//       // Successfull 
//       dispatch(getDataSuccess(r.data.data))
//       // console.log(r.data)
//       }).catch((err)=>{
//         // Failure
//         dispatch(getDataFailure())
//           console.log(err)
//       })}

//  else{  
      dispatch(getDataRequest())
      return axios.get(`http://localhost:8080/job?page=${page}&filter=${filter}`).then((r)=>{
      // Successfull 
      dispatch(getDataSuccess(r.data.data))
      // console.log(r.data)
      }).catch((err)=>{
        // Failure
        dispatch(getDataFailure())
          console.log(err)
      })
    // }
      
    
  }