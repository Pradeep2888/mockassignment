import { reducer } from "./AppReducer/reducer";

const { legacy_createStore, applyMiddleware } = require("redux");
const { default: thunk } = require("redux-thunk");






const store=legacy_createStore(reducer,applyMiddleware(thunk))

export {store}