import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Joblisting from '../Components/Joblisting'
import Jobposting from '../Components/Jobposting'

function AllRoutes() {
  return (
    <div>
        <Routes>
            <Route path='/' element={<Joblisting/>} />
            <Route path='/jobposting' element={<Jobposting/>} />
        </Routes>
    </div>
  )
}

export default AllRoutes