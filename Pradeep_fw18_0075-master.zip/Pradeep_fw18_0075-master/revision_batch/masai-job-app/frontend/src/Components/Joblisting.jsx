import React, { useEffect, useState } from 'react'
import { shallowEqual, useDispatch, useSelector } from 'react-redux'
import { Link } from 'react-router-dom'
import { getData } from '../Redux/AppReducer/action'
import JobCard from './JobCard'
import {
  FormControl,
  Box,
  Input,
  Select,
  Button
} from '@chakra-ui/react'

function Joblisting() {
  const [filter,setFilter]=useState("")
  const [page,setPage]=useState(1)
  const [search,setSearch]=useState("")

    const dispatch=useDispatch()
    const {data,isLoading,isError}=useSelector((state)=>{
        return {
            data:state.data,
            isLoading:state.isLoading,
            isError:state.isError
          }
    },shallowEqual)

    // console.log(data)

    useEffect(()=>{

        if(data.length===0){
           dispatch(getData)
        }
        
       },[])

       useEffect(()=>{
        dispatch(getData(filter,search,page))
    },[filter,search,page])

  return (
    <div>
       <Link to={"/jobposting"} >Job Posting</Link>
       <div>
       <Select placeholder='Select Role' id='role' onChange={(e)=>setFilter(e.target.value)} >
                  <option value='frontend'>Frontend</option>
                  <option value='backend'>Backend</option>
                  <option value='fullstack'>FullStack</option>
        </Select>
       </div>

       <div>
        <button disabled={page===1} onClick={()=>setPage(page-1)}>-</button>
        <h1>{page}</h1>
        <button  onClick={()=>setPage(page+1)}>+</button>
       </div>



       <div>

      {
        data?.map((item)=>(
          <JobCard key={item._id} 
          company={item.company}
          postedAt={item.postedAt}
          city={item.city}
          location={item.location}
          role={item.role}
          level={item.level}
          contract={item.contract}
          position={item.position}
          language={item.language}

          />
        ))
      }
      </div>
         
    </div>
  )
}

export default Joblisting