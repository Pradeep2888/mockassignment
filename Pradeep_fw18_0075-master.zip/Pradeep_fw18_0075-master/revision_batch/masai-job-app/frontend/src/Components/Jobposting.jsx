import React, { useState } from 'react'
import { Link } from 'react-router-dom'
import {
    FormControl,
    Box,
    Input,
    Select,
    Button
  } from '@chakra-ui/react'
import { shallowEqual, useDispatch, useSelector } from 'react-redux'
import axios from 'axios'

function Jobposting() {

    const [name,setName]=useState("")
    const [city,setCity]=useState("")
    const [location,setLocation]=useState("")
    const [role,setRole]=useState("")
    const [level,setLevel]=useState("")
    const [position,setPosition]=useState("")
    const [language,setLanguage]=useState("")
    const [contract,setContract]=useState("")

    // const dispatch=useDispatch()
    // const data=useSelector((state)=>{
    //     return state
    // },shallowEqual)


    const postData=(obj)=>{
        axios.post(`https://job-test-api.onrender.com/job/addjob`,obj)
        .then((r)=>{
            console.log(r)
        })
        .catch((e)=>{
            console.log(e)
        })
    }


    const handelChange=()=>{
        let today = new Date();
        let dd = String(today.getDate()).padStart(2, '0');
        let mm = String(today.getMonth() + 1).padStart(2, '0'); //January is 0!
        let yyyy = today.getFullYear();

        today = mm + '-' + dd + '-' + yyyy

        
        let obj={
            company:name,
            postedAt:today ,
            city,
            location,
            role,
            level,
            contract,
            position,
            language
        }

       postData(obj)
       
    }

  return (
    <div>
        <Link to={"/"} >Job Listing</Link>

       
       <Box>
       <FormControl  >
                <Input type='text' id='name' placeholder='Company Name' onChange={(e)=>setName(e.target.value)} /> 
                <Input type='text' id='city' placeholder='City Name' onChange={(e)=>setCity(e.target.value)} /> 
                <Input type='text' id='location' placeholder='Location'onChange={(e)=>setLocation(e.target.value)} />

                <Select placeholder='Select Role' id='role' onChange={(e)=>setRole(e.target.value)} >
                  <option value='frontend'>Frontend</option>
                  <option value='backend'>Backend</option>
                  <option value='fullstack'>FullStack</option>
                </Select>

                <Select placeholder='Select Level' id='level' onChange={(e)=>setLevel(e.target.value)} >
                  <option value='junier'>Junior</option>
                  <option value='senier'>Senior</option>
                </Select>

                <Select placeholder='Select Position' id='position' onChange={(e)=>setPosition(e.target.value)} >
                  <option value='junior frontend developer'> Junior Frontend Developer</option>
                  <option value='backend developer'>Backend Developer</option>
                  <option value='junior backend developer'>Junior Backend Developer</option>
                  <option value='fsd'>FSD</option>
                </Select>
                <Select placeholder='Select Language' id='language' onChange={(e)=>setLanguage(e.target.value)} >
                  <option value='javascript'>Javascript</option>
                  <option value='java'>Java</option>
                  <option value='c'>C</option>
                  <option value='c++'>C++</option>
                </Select>

                <Select placeholder='Select Contract' id='contract'  onChange={(e)=>setContract(e.target.value)} >
                  <option value='full-time'>Full Time</option>
                  <option value='parttime'>Part Time</option>
                </Select>

                

        </FormControl>
       </Box>
       <Button onClick={()=>handelChange()} >Submit</Button>


    </div>
  )
}

export default Jobposting