import React from 'react'
import { Avatar, Box ,WrapItem,Image ,Text} from '@chakra-ui/react'

function JobCard({
    company,
    postedAt,
    city,
    location,
    role,
    level,
    contract,
    position,
    language
}) {
  return (
    <div>
        <Box marginBottom={"1%"} mt={"20px"} display="flex">
          <WrapItem height={"5%"} width="auto" >
          <Image mr={"10px"} width="5%" borderRadius={"50%"} name='Dan Abrahmov' src='https://bit.ly/dan-abramov' />
          <Text mr={"10px"}>{role}</Text>
          <Text mr={"10px"}>{company}</Text>
          <Text mr={"10px"}>{postedAt}</Text>
          <Text mr={"10px"}>{city}</Text>
          <Text mr={"10px"}>{level}</Text>
          <Text mr={"10px"}>{role}</Text>
          <Text mr={"10px"}>{contract}</Text>
          <Text mr={"10px"}>{position}</Text>
          <Text mr={"10px"}>{language}</Text>
         </WrapItem>
        </Box>
    </div>
  )
}

export default JobCard