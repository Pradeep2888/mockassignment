import axios from 'axios'
import React, { useEffect, useState } from 'react'

function Playzone() {
    const [random,setRandom]=useState("")
    const [string,setString]=useState("")
    const [score,setScore]=useState(0)
    const [counter, setCounter] = useState(0)

    const getRendom=()=>{
        let data=JSON.parse( localStorage.getItem("obj") )
        // console.log(data)
        if(data.level==="low"){
            setCounter(30)
        }
       else if(data.level==="medium"){
        setCounter(20)
        }

       else if(data.level==="high"){
        setCounter(10)
        }
        

        axios.get(`https://masai-word-game.onrender.com/score/getrendom`)
        .then((r)=>{
            // console.log(r)
            setRandom(r.data.string.trim())

        })
        .catch((e)=>{
           console.log(e)
        })

    }

    const  updateScore=()=>{

        axios.patch(`http://localhost:8080/score/scoreupdate`,{"score":score})
        .then((r)=>{
            console.log(r)
        })
        .catch((e)=>{
           console.log(e)
        })

    }

    const handelSubmit=()=>{
       
        if(counter===0){
          setCounter(0)
          updateScore()
        }
        else if(string.trim()===random.trim()){
            setScore(score+random.length)
            
        }
        else{
            setScore(score-random.length)
            
        }
        getScore()
        
    }

    const getScore=()=>{
        // console.log(score)
    }

    const getTimer=()=>{
         
       
    }


    useEffect(()=>{
        // getLevel()
        getRendom()
    },[score])
    

    
    useEffect(()=>{
        // getRendom()
        const timer = counter > 0 && setInterval(() => setCounter(counter - 1), 1000);
           return () => clearInterval(timer);
    },[counter])

  
   
    
  return (
    <div>
          
          <div>
            <h1>Word:{random}</h1>
          </div>

          <div>
            <h3>{counter}</h3>
          </div>


        <div>
        <input placeholder='Type Word Here' onChange={(e)=>setString(e.target.value)} />
        <button onClick={()=>handelSubmit()} >Submit</button>
        </div>
    </div>
  )
}

export default Playzone