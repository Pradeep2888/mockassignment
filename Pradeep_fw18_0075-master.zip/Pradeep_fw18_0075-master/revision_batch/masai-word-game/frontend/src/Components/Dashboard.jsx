
import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'

function Dashboard() {
    const navigate=useNavigate()

    const [name,setName]=useState("")
    const [level,setLevel]=useState("")

    const handelSubmit=()=>{
     console.log(name,level)
     postData()
    }

    const postData=()=>{
        let obj={
            name,
            level,
            "score":0
        }
        console.log(obj)
        axios.post(`http://localhost:8080/score/adduser`,obj)
        .then((r)=>{
            localStorage.setItem( "obj", JSON.stringify(obj) )
            navigate("/playzone")
        })
        .catch((e)=>{
           alert("Some Thing went Wrong")
        })
    }

    
    const getData=()=>{

        axios.get(`http://localhost:8080/score`)
        .then((r)=>{
            console.log(r)
        })
        .catch((e)=>{
           console.log(e)
        })

    }
    
    useEffect(()=>{
        getData()
    
    },[])


  return (
    <div>
        <h1>Dashboard</h1>

        <form >
            <input placeholder='Write your Name' onChange={(e)=>  setName(e.target.value)} />
            <select onChange={(e)=>setLevel(e.target.value)} >
                <option  >Select Level</option>
                <option value={"low"} >Low</option>
                <option value={"Medium"}>Medium</option>
                <option value={"high"}>High</option>
            </select>
        </form>
        <button onClick={()=>handelSubmit()} >Submit</button>
    </div>
  )
}

export default Dashboard