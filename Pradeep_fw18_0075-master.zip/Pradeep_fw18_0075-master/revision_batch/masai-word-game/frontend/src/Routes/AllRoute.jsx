import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Dashboard from '../Components/Dashboard'
import Playzone from '../Components/Playzone'

function AllRoute() {
  return (
    <div>
        <Routes>
            <Route path='/' element={<Dashboard/>} />
            <Route path='/playzone' element={<Playzone/>} />
        </Routes>
    </div>
  )
}

export default AllRoute