import logo from './logo.svg';
import './App.css';
import AllRoute from './Routes/AllRoute';

function App() {
  return (
    <div className="App">
     <AllRoute/>
    </div>
  );
}

export default App;
