function setJokes(data) {
  // get the joke-container div
  // craete a div and add a p tag in it with class as joke-text
  // append the div to joke-container div
  let container=document.getElementById("joke-container")
  container.innerHTML=""
  // let div=document.createElement("div")
  let p=document.createElement("p")
  p.setAttribute("id","joke-text")
    p.innerText=data.value
 container.append(p)
// div.append(p)
// container.append(div)
  
}

let getRandomJoke = async () => {
  // fetch request to get a random joke
  // return the data ona successfull request
  // return error text on failure
  try{
    let x=await fetch('https://api.chucknorris.io/jokes/random')
    let data=await x.json()
    setJokes(data)
  }
  catch(err){
    console.log("something went wrong")
  }
};
let getJokeByCategory = async (event) => {
  try{
    let x=await fetch(`https://api.chucknorris.io/jokes/random?category=${event}`)
    let data=await x.json()
    setJokes(data)
  }
  catch(err){
    console.log("something went wrong")
  }
};
window.onload = function () {
  // add click event to button
  // add change event to select tag
  document.getElementById("get-jokes-data").addEventListener("click",getRandomJoke)
  document.getElementById("get-category").addEventListener("change",()=>{
    let event= document.getElementById("get-category").value
    getJokeByCategory(event)
  })
};

// donot chnage the export statement

if (typeof exports !== "undefined") {
  module.exports = {
    getRandomJoke,
    setJokes,
    getJokeByCategory,
  };
}
