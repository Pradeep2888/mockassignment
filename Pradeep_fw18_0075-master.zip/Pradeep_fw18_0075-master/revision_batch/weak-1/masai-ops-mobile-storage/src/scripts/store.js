let arr=JSON.parse(localStorage.getItem("mobile_data")) || []

let display=document.getElementById("mobile_list")
function showProduct(arr){
    
    
    arr.forEach((el,i)=>{
     let card=document.createElement("div")
     card.setAttribute("class","mobile")

     let image=document.createElement("img")
    image.src=el.image
    let brand=document.createElement("h3")
    brand.innerText=el.brand
    let name=document.createElement("h3")
    name.innerText=el.name
    let price=document.createElement("h3")
    price.innerText=el.price
    let button=document.createElement("button")
    button.innerText="Delete"
    button.setAttribute("class","remove")
    button.addEventListener("click",()=>{
      deleteItem(el,i)
    })
   
     card.append(image,brand,name,price,button)

    display.append(card)    
    })
}

showProduct(arr)

function deleteItem(el,index){
    arr.splice(index,1)
    localStorage.setItem("mobile_data",JSON.stringify(arr))
    window.location.reload()
}

document.getElementById("sort_lth").addEventListener("click",shortlowtohigh)
document.getElementById("sort_htl").addEventListener("click",hightolow)

function shortlowtohigh(){
arr.sort((a,b)=>{
    return a.price-b.price
})
display.innerHTML=""
showProduct(arr)
}
function hightolow(){
    arr.sort((a,b)=>{
        return b.price-a.price
    })
    display.innerHTML=""
    showProduct(arr)
}