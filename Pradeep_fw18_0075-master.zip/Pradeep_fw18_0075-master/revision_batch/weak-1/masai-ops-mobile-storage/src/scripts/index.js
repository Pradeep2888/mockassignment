let arr=JSON.parse(localStorage.getItem("mobile_data")) || []

document.getElementById("mobile_form").addEventListener("submit",FormData)

function FormData(e){
    e.preventDefault()
    let name=document.getElementById("mobile_name").value
    let brand=document.getElementById("mobile_brand").value
    let price=document.getElementById("mobile_price").value
    let image=document.getElementById("mobile_image").value
    
    let obj={
        name,
        brand,
        price,
        image
    }
    arr.push(obj)
    localStorage.setItem("mobile_data",JSON.stringify(arr))
    document.getElementById("mobile_form").reset()
}