const getCategoriesData = async () => {
  try{
    
    let x=await fetch("https://www.themealdb.com/api/json/v1/1/filter.php?c=Seafood");
    let data=await x.json();
    console.log(data);
    return data
}
catch(error){
return "something went wrong"
}

};

const getIngredientData = async () => {
  try{
    let x=await fetch("https://www.themealdb.com/api/json/v1/1/filter.php?i=chicken_breast")
    let data=await x.json();
    console.log(data) 
    return data
  }
  catch(err){
    return "something went wrong"
  }
};

window.onload = function () {
  document.getElementById('get-category-data').addEventListener("click",getCategoriesData)
  document.getElementById('get-ingredient-data').addEventListener("click",getIngredientData)
};

// donot chnage the export statement

if (typeof exports !== "undefined") {
  module.exports = {
    getCategoriesData,
    getIngredientData,
  };
}
