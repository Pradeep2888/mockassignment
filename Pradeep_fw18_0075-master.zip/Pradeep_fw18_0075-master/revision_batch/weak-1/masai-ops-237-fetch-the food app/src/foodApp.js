const getCategoriesData = async () => {
 let response=await fetch("https://www.themealdb.com/api/json/v1/1/filter.php?c=Seafood")
 .then((r)=>{
  r.json().then((res)=>{
    console.log(res)
  })
 })
 .catch((err)=>{
  console.log("something went wrong")
 })
};

const getIngredientData = async () => {
  // code here
  let response=await fetch("https://www.themealdb.com/api/json/v1/1/filter.php?i=chicken_breast")
  .then((r)=>{
   r.json().then((res)=>{
     console.log(res)
   })
  })
  .catch((err)=>{
   console.log("something went wrong")
  })
};

window.onload = function () {
  //  get the buttons here and add click event
  document.getElementById('get-category-data').addEventListener("click",getCategoriesData)
  document.getElementById('get-ingredient-data').addEventListener("click",getIngredientData)
};

// donot chnage the export statement

if (typeof exports !== "undefined") {
  module.exports = {
    getCategoriesData,
    getIngredientData,
  };
}
