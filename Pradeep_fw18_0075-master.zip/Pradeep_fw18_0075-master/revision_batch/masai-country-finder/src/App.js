import logo from './logo.svg';
import './App.css';
import { useEffect, useState } from 'react';
import ProductPage from './Components/ProductPage';

function App() {
  const [data,setData]=useState()
  const [sort,setSort]=useState("asc")
  const [region,setRegion]=useState("")

  const getData=async()=>{
      try{

        let res=await fetch(`https://restcountries.com/v3.1/all`)
        let data=await res.json()
       setData(data)
      }
      catch(err){
        console.log(err)
       }
  }
  const handelFilter=async(e)=>{
   let val =e.target.value
   setRegion(val)
      try{

        let res=await fetch(`https://restcountries.com/v3.1/region/${val}`)
        let data=await res.json()
       setData(data)
      }
      catch(err){
        console.log(err)
       }
  }

  const handleSort=async(val,data)=>{
  
console.log(region)

if(region==="" && val==="desc"){
  try{

    let res=await fetch(`https://restcountries.com/v3.1/all`)
    let data=await res.json()
    data.sort((a,b)=>{
      return b.population -a.population
    })
   setData(data)
  }
  catch(err){
    console.log(err)
   }
}
else if(region==="" && val==="asc"){
  try{

    let res=await fetch(`https://restcountries.com/v3.1/all`)
    let data=await res.json()
    data.sort((a,b)=>{
      return a.population -b.population
    })
   setData(data)
  }
  catch(err){
    console.log(err)
   }
}


else  if(val==="desc"){
      try{

        let res=await fetch(`https://restcountries.com/v3.1/region/${region}`)
        let data=await res.json()
        data.sort((a,b)=>{
          return b.population -a.population
        })
       setData(data)
      }
      catch(err){
        console.log(err)
       }
   

    }
 else{
  try{

    let res=await fetch(`https://restcountries.com/v3.1/region/${region}`)
    let data=await res.json()
    data.sort((a,b)=>{
      return a.population -b.population
    })
   setData(data)
  }
  catch(err){
    console.log(err)
   }

 }

   
}

  


  useEffect(()=>{
    getData()
   
  },[])

  return (
    <div className="App">

        <h1 data-testid="product-page-title">Country Page</h1>
              <button onClick={()=>handleSort("asc",data)} data-testid="low-to-high">Sort Population low to high</button>
              <button  onClick={()=>handleSort("desc",data)} data-testid="high-to-low">Sort Population high to low</button>
              <div>
                <label>Region</label>
                <select onClick={handelFilter}  data-testid="limit-select">
                  <option value="africa"> Africa</option>
                  <option value="america">America</option>
                  <option value="europe"> Europe</option>
                  <option value="asia">Asia</option>
                  <option value="oceania"> Oceania</option>
                </select>
               </div>

     <ProductPage data={data} />
    </div>
  );
}

export default App;
