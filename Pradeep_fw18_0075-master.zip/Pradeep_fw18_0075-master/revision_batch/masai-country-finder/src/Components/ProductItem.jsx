import { Button, Card, CardBody, Heading, Image, Modal, ModalBody, ModalCloseButton, ModalContent, ModalFooter, ModalHeader, ModalOverlay, Stack, Text, useDisclosure } from '@chakra-ui/react'
import React from 'react'

function ProductItem({id,name,flag_image,population,region,capital,native,sub_region,currency,language,border}) {
    const { isOpen, onOpen, onClose } = useDisclosure()
    // console.log(currency)
  return (
    <div id='card'>
        <Card maxW='sm'>
  <CardBody>
    <Image
      src={flag_image}
      alt='Green double couch with wooden legs'
      borderRadius='lg'
    />
    <Stack mt='6' spacing='3'>
      <Heading size='sm'>{name}</Heading>
      <Text>Population:{population}</Text>
      <Text>Region:{region}</Text>
    
    </Stack>
  </CardBody>
</Card>
{/* <div>
<Button onClick={onOpen}>Open Modal</Button>

              <Modal  background={"grey"} isOpen={isOpen} onClose={onClose}>
                <ModalOverlay />
                <ModalContent>
                 <Text>Sub Region:{sub_region}</Text>
                
                 

                  <ModalFooter>
                    <Button colorScheme="blue" mr={3} onClick={onClose}>
                      Close
                    </Button>
                  </ModalFooter>
                </ModalContent>
              </Modal>
      </div> */}
    </div>
  )
}

export default ProductItem