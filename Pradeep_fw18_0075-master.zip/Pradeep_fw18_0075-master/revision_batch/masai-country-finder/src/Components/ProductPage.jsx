import React from 'react'
import ProductItem from './ProductItem'

function ProductPage({data}) {
    // console.log(data)
  return (
    <div id='area'>
       {data?.map((item,index) => (<ProductItem key={index} name={item.name.official}  flag_image={item.flags.png} population={item.population} region={item.region} capital={item.capital} native={item.name.nativeName} sub_region={item.subregion} currency={item.currencies} language={item.languages} border={item.borders} />))}
    </div>
  )
}

export default ProductPage