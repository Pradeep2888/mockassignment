import React from 'react'
import { Navigate, useNavigate } from 'react-router'

function ProductCard({index,id,brand,category,image,price,title}) {

    const navigate=useNavigate()

    const handleClick=(id)=>{
        navigate(`/product/${id}`)
    }
  return (
    <div onClick={()=>handleClick(index)} >
        <h3>Brand:{brand}</h3>
        <h5>Title:{title}</h5>
        <img src={image} alt={title}/>
        <h5>Category:{category}</h5>
        <h5>Price:{price}</h5>
    </div>
  )
}

export default ProductCard