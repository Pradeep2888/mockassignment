import React from 'react'
import { useState } from 'react'
import { useEffect } from 'react'
import { shallowEqual, useDispatch, useSelector } from 'react-redux'
import { getData } from '../Redux/AppReducer/action'
import ProductCard from './ProductCard'

function ProductPage() {

    const dispatch=useDispatch()
    const {data,isLoading,isError}=useSelector((state)=>{
        return {
            data:state.data,
            isLoading:state.isLoading,
            isError:state.isError
          }
    },shallowEqual)

    const [counter,setCounter]=useState(1)
    const handelCount=(v)=>{
         setCounter(counter+v)
    }

     const [filter,setFilter]=useState("")
    const handleFilter=(e)=>{
        setFilter(e.target.value)
    }
     const [order,setOrder]=useState("asc")
    const handleOrder=(v)=>{
        setOrder(v)
    }

    

    useEffect(()=>{

     if(data.length===0){
        dispatch(getData)
     }
    },[])


    useEffect(()=>{
        dispatch(getData(counter,filter,order))
    },[counter,filter,order])


  return (
    <div>

        <div>
            <a href='/'>Home</a>
            <a href='/cart'>cart</a>
            <a href='/order' >order</a>
        </div>
        
         <div style={{"display":"flex"}} >
            <button disabled={counter===1} onClick={()=>handelCount(-1)} >Previous</button>
            <p>Page Number:{counter}</p>
            <button disabled={counter===4} onClick={()=>handelCount(1)}>Next</button>
         </div>
        
        <div>
            <select onChange={(e)=>handleFilter(e)}>
                <option value="">Change Category</option>
                <option value="kids">Kids</option>
                <option value="women">women</option>
                <option value="homedecor">Home Decor</option>
            </select>
        </div>
        <div>
            <button onClick={()=>handleOrder("asc")} >Low to High</button>
            <button onClick={()=>handleOrder("desc")} >High to Low</button>
        </div>

        <div id='card' >

       {
        data.data?.map((item,index)=><ProductCard key={item.id} index={index} id={item.id} brand={item.brand} category={item.category} image={item.image} price={item.price} title={item.title} />)
       }
       </div>
    </div>
  )
}

export default ProductPage