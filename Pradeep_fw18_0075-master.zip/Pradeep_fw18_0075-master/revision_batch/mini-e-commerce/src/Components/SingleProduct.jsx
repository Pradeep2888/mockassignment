import React from 'react'
import { useEffect } from 'react'
import { useState } from 'react'
import { shallowEqual, useDispatch, useSelector } from 'react-redux'
import { useParams } from 'react-router'
import { getData } from '../Redux/AppReducer/action'

function SingleProduct() {
    const {id}=useParams()
    const dispatch=useDispatch()
    const {data,isLoading,isError}=useSelector((state)=>{
        return {
            data:state.data,
            isLoading:state.isLoading,
            isError:state.isError
          }
    },shallowEqual)
  const [data1,setData1]=useState([])
  
//   const getData=()=>{
//     data.data.map((el)=>{
//         if(el.id===Number(id)){
           
//             console.log("hi")
//         }
//     })
//   }

console.log(data.data[Number(id)],id)

// useEffect(()=>{
// getData()
// },[])

 
  return (
    <div>
         <div  >
         <h3>Brand:{data.data[Number(id)].brand}</h3>
        <h5>Title:{data.data[Number(id)].title}</h5>
        <img src={data.data[Number(id)].image}/>
        <h5>Category:{data.data[Number(id)].category}</h5>
        <h5>Price:{data.data[Number(id)].price}</h5>
        <button>Add to cart</button>

    </div>
    </div>
  )
}

export default SingleProduct