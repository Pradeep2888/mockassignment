import React from 'react'
import { Route, Router, Routes } from 'react-router'
import ProductPage from '../Components/ProductPage'
import SingleProduct from '../Components/SingleProduct'

function AllRouter() {
  return (
    <div>
        <Routes>
            <Route path='/'  element={<ProductPage/>} />
            <Route path='/product/:id'  element={<SingleProduct/>} />
            <Route path='/cart'  element={<div>Welcome to home</div>} />
            <Route path='/order'  element={<div>Welcome to home</div>} />
        </Routes>
    </div>
  )
}

export default AllRouter