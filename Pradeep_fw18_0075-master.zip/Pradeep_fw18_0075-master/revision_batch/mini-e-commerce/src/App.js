import logo from './logo.svg';
import './App.css';
import AllRouter from './Rotes/AllRouter';

function App() {
  return (
    <div className="App">
      <AllRouter/>
    </div>
  );
}

export default App;
