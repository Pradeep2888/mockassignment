import axios from "axios"
import { GET_DATA_FAILURE, GET_DATA_REQUEST, GET_DATA_SUCCESS } from "./actionType"


export const getDataRequest=()=>{
    return {
        type:GET_DATA_REQUEST
    }
}

export const getDataSuccess=(payload)=>{
    return {
        type:GET_DATA_SUCCESS,
        payload
    }
}

export const getDataFailure=()=>{
    return {
        type:GET_DATA_FAILURE
    }
}







export const getData=(counter,filter,order)=>(dispatch)=>{
    console.log(counter,filter)
 if(filter==="" && order===""){   // Request
      dispatch(getDataRequest())
      return axios.get(`https://dbioz2ek0e.execute-api.ap-south-1.amazonaws.com/mockapi/get-products/?page=${counter}&limit=12`).then((r)=>{
      // Successfull 
      dispatch(getDataSuccess(r.data))
      // console.log(r.data)
      }).catch((err)=>{
        // Failure
        dispatch(getDataFailure())
          console.log(err)
      })}
 else if(filter==="" && order!==""){   // Request
      dispatch(getDataRequest())
      return axios.get(`https://dbioz2ek0e.execute-api.ap-south-1.amazonaws.com/mockapi/get-products/?page=${counter}&limit=12&orderBy=${order}`).then((r)=>{
      // Successfull 
      dispatch(getDataSuccess(r.data))
      // console.log(r.data)
      }).catch((err)=>{
        // Failure
        dispatch(getDataFailure())
          console.log(err)
      })}
    else if(filter!=="" && order===""){   // Request
        dispatch(getDataRequest())
        return axios.get(`https://dbioz2ek0e.execute-api.ap-south-1.amazonaws.com/mockapi/get-products/?page=${counter}&limit=12&orderBy=$asc&category=${filter}`).then((r)=>{
        // Successfull 
        dispatch(getDataSuccess(r.data))
        // console.log(r.data)
        }).catch((err)=>{
          // Failure
          dispatch(getDataFailure())
            console.log(err)
        })}
 else if(filter!=="" && order!==""){   // Request
      dispatch(getDataRequest())
      return axios.get(`https://dbioz2ek0e.execute-api.ap-south-1.amazonaws.com/mockapi/get-products/?page=${counter}&limit=12&orderBy=${order}&category=${filter}`).then((r)=>{
      // Successfull 
      dispatch(getDataSuccess(r.data))
      // console.log(r.data)
      }).catch((err)=>{
        // Failure
        dispatch(getDataFailure())
          console.log(err)
      })}

    
  }

