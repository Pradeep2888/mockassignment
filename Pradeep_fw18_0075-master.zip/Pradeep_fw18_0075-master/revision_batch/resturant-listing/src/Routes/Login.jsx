import axios from "axios";
import { useContext, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {  AuthContext } from "../Context/AuthContext";

function Login() {
  const [userData, setUserData] = useState({ email: "", password: "" })
  const { loginUser } = useContext( AuthContext)
  const navigate = useNavigate()

  // "email": "eve.holt@reqres.in",
  // "password": "cityslicka"


  const handleInput = (e) => {
    const { name, value } = e.target
    setUserData({ ...userData, [name]: value })
  }

  const handleLogin = (e) => {
    e.preventDefault()

    axios.post("https://reqres.in/api/login",userData)
    .then((r)=>{
      loginUser("ABCD")
      navigate("/dashboard")
    })
    .catch((e)=>{
      console.log(e)
    })
    // console.log(userData)

  }
  return (
    <div>
      <form data-testid="login-form" onSubmit={handleLogin}>
        <div>
          <label>
            Email
            <input data-testid="email-input" type="email" placeholder="email" onChange={handleInput} name="email" />
          </label>
        </div>
        <div>
          <label>
            Password
            <input
              data-testid="password-input"
              type="password"
              placeholder="password"
              name="password"
              onChange={handleInput} 
            />
          </label>
        </div>
        <div>
          <input data-testid="form-submit" type="submit" value="SUBMIT" />
        </div>
      </form>
      <div>
        <Link to="/">Go Back</Link>
      </div>
    </div>
  );
}
export default Login;
