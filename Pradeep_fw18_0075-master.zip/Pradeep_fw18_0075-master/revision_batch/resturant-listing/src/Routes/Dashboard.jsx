import axios from "axios";
import { useContext, useEffect, useState } from "react";
import RestaurantTable from "../Components/RestaurantTable";
import {AuthContext } from "../Context/AuthContext";
import Pagination from "../Components/Pagination"

function Dashboard() {
  const { state, logoutUser } = useContext( AuthContext)
  const [data, setData] = useState([])
  const [page, setPage] = useState(1)
  const [limit, setLimit] = useState(10)
  const [total, setTotalPages] = useState(0)


  const getData = (page, limit) => {
    return axios.get(`https://dbioz2ek0e.execute-api.ap-south-1.amazonaws.com/mockapi/getrestaurants?page=${page}&limit=${limit}`)
  }




  useEffect(()=>{
    getData(page, limit).then((res) => {
      setData(res.data.data)
      setTotalPages(res.data.totalPages)
      console.log(res.data.data)
    })
  },[page, limit])
  
  return (
    <div>
      <h3>Dashboard</h3>
      <div>
        <button data-testid="logout-btn"  onClick={() => logoutUser()}  >Logout</button>
        <p>
          Token:
          <b data-testid="user-token">{state.token}</b>
        </p>
      </div>
      <div style={{ display: "flex", justifyContent: "center" }}>
        {/* restaurant table */}
        <RestaurantTable data={data}/>
      </div>
      <div data-testid="pagination-container"></div>
      <Pagination totalPages={total} currentPage={page} handlePageChange={(value) => setPage(value)}/>
    </div>
  );
}

export default Dashboard;
