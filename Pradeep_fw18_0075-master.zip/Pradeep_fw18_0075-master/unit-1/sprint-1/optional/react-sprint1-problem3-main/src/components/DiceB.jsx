const DiceB=({player,handelClick,handelPlayer})=>{
    return(
        <div>
            <h2 data-testid="dice-B-value">Dice B: {/*Whatever value dice is giving should be here*/}</h2>
            <button disabled={player===true} onClick={()=>{handelClick();handelPlayer()}} data-testid="dice-B-button">Player 2: Roll Dice</button>
        </div>
    )
}

export default DiceB;