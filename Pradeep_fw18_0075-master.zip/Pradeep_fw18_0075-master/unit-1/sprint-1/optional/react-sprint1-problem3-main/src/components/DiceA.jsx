const DiceA=({handelClick,handelPlayer,player})=>{
    return(
        <div>
            <h2 data-testid="dice-A-value">Dice A: {/*Whatever value dice is giving should be here*/}</h2>
            <button disabled={player===false} data-testid="dice-A-button" onClick={()=>{handelClick();handelPlayer()}}>Player 1: Roll Dice</button>
        </div>
    )
}

export default DiceA;