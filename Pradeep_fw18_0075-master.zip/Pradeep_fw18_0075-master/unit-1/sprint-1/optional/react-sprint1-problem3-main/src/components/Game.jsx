import DiceB from "./DiceB";
import DiceA from "./DiceA";
import { useState } from "react";
const Game=()=>{
    const [score,setScore]=useState(0)
    const [player,setPlayer]=useState(true)
    const handelPlayer=()=>{
        // console.log("player")
        player===true?setPlayer(false):setPlayer(true)
    }
    const handelClick=()=>{
        console.log("hi")
    }
    return (
        <div>
            <h1 data-testid="turn-heading">{`Player ${player===true?"1":"2"} it is your turn`}</h1>
            <DiceA handelClick={handelClick} handelPlayer={handelPlayer} player={player}/>
            <DiceB handelClick={handelClick} handelPlayer={handelPlayer} player={player}/>
            <h3 data-testid="player1-score">Player 1 Scores: {/*Player 1 scores should be here*/}</h3>
            <h3 data-testid="player2-score">Player 2 Scores: {/*Player 1 scores should be here*/}</h3>
            <h1 data-testid="result-tag">{/* Result tag should be here */}</h1>
        </div>
    )
}

export default Game;
