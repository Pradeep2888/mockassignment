import DiceB from "./DiceB";
import DiceA from "./DiceA";
import { useState } from "react";
import { useEffect } from "react";
const Game=()=>{
    const [score1,setScore1]=useState(0)
    const [score2,setScore2]=useState(0)
    const [player,setPlayer]=useState(true)
    const [count1,setCount1]=useState(1)
    const [count2,setCount2]=useState(1)
    const [total,setTotal]=useState(0)
    const handelPlayer=()=>{
        // console.log("player")
        // setCount(count+1)
        player===true?setPlayer(false):setPlayer(true)
        let getRandomInt=Math.floor(Math.random() * 7);
        player===true?setScore1((score1)=>score1+getRandomInt):setScore2((score2)=>score2+getRandomInt)
    }
    const handelClick1=()=>{
        setCount1(count1+1)
        console.log(count1+"count1")
    }
    const handelClick2=()=>{
        setCount2(count2+1)
        console.log(count2+"count2")
    }
  
   
    return (
        <div>
            <h1 data-testid="turn-heading">{`Player ${player===true?1:2}, It is your turn!!`}</h1>
            <DiceA handelClick1={handelClick1} handelPlayer={handelPlayer} player={player} count1={count1}/>
            <DiceB handelClick2={handelClick2} handelPlayer={handelPlayer} player={player} count2={count2}/>
            <h3 data-testid="player1-score">Player 1 Scores: {score1}</h3>
            <h3 data-testid="player2-score">Player 2 Scores: {score2}</h3>
            <h1 id="result" data-testid="result-tag"></h1>
        </div>
    )
}

export default Game;
