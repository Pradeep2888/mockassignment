const DiceA=({handelClick1,handelPlayer,player,count1})=>{
    return(
        <div>
            <h2 data-testid="dice-A-value">Dice A: {/*Whatever value dice is giving should be here*/}</h2>
            <button disabled={player===false || count1===6} data-testid="dice-A-button" onClick={()=>{handelClick1();handelPlayer()}}>Player 1: Roll Dice</button>
        </div>
    )
}

export default DiceA;