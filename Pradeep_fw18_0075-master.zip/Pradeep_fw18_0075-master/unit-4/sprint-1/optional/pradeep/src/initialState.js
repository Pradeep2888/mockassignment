//DO NOT CHANGE THE STRUCTURE OF THIS INITIAL STATE;
const initialState = {
  email: "",
  password: "",
  isAuth: false,
  token: "",
  isLoading: false,
  isError: false,
};

export { initialState };
