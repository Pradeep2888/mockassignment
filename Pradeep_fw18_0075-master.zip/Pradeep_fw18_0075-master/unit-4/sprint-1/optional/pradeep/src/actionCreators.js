// //create action creator functions here, using the action types from actionTypes.js;
// import { EMAIL,PASSWORD,LOGIN_REQUEST,LOGIN_SUCCESS,LOGIN_FAILURE } from "./actionTypes" 
// export const handelEmail=()=>{
//     // event.preventDefault()
// type:EMAIL
// // payload:{e.target.value}
// }
// export const handelPassword=()=>{
//     // event.preventDefault()
//     type:PASSWORD
//     // payload:e.target.value
// }
// export const handelLogin=()=>{
//     // event.preventDefault()
//     type:LOGIN_REQUEST
// }
//     // export {handelEmail,handelLogin,handelPassword}