import Slide from "./Components/Slide";
import "./styles.css";
import React from "react";

// set this as the
const data = [
  {
    id: 1,
    title: "Intro to React",
    description: "React is a Javascript UI library"
  },
  {
    id: 2,
    title: "Intro to Props",
    description: "Props are just properties"
  },
  {
    id: 3,
    title: "Sate management",
    description: "Learn how to manage state"
  }
];

export default function App(data) {
  const [todo, settodo] = React.useState(1);

  const detailist = data[todo];
  // const [id:"id" , title:"title", description:"description"]=detailist

  function handelPre() {
    //   {
    //     if (todo >= 1) {
    settodo(todo - 1);
    //     }
    //   }
  }
  function handelNext() {
    //   {
    //     if (todo < data.length-1) {
    settodo(todo + 1);
    //     }
    //   }
  }
  // console.log(todo);
  return (
    <div className="App">
      <h1 data-testid="header">Slides</h1>
      <Slide
        id="1"
        title="Intro to React"
        description="React is a Javascript UI library"
      />
      <Slide
        id="2"
        title="Intro to Props"
        description="Props are just properties"
      />
      <Slide
        id="3"
        title="Sate management"
        description="Learn how to manage state"
      />
      <button data-testid="prev" onClick={handelPre}>
        Prev
      </button>
      <button data-testid="next" onClick={handelNext}>
        Next
      </button>
    </div>
  );
}
