function Slide(prop) {
  console.log(prop);
  return (
    <div className="slide-container" data-testid="slide">
      <h3 data-testid="title">{prop.title}</h3>
      <p data-testid="description">{prop.description}</p>
    </div>
  );
}

export default Slide;
