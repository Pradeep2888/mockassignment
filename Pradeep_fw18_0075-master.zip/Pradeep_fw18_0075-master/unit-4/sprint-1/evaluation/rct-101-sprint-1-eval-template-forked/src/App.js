import List from "./Components/List";
import "./styles.css";

export default function App() {
  return (
    <div className="App">
      <h1>Limited List</h1>
      <List />
    </div>
  );
}
