import { useEffect } from 'react';
import { useState } from 'react';
import Card from './Card';
const InputTags=()=>{
    const [name,setName]=useState("")
    const [height,setHeight]=useState(0)
    const [weight,setWeight]=useState(0)
    const [power,setPower]=useState(0)
    const [data,setData]=useState([])
    const [state,setState]=useState(false)
    const [actual,setActual]=useState([])

    const handleName=(e)=>{
       
        e.preventDefault()
     setName(e.target.value)
    }
    const handleHeight=(e)=>{
     setHeight(e.target.value)
    }
    const handleWeight=(e)=>{
    setWeight(e.target.value)
    }
    const handlePower=(e)=>{
     setPower(e.target.value)
    }
    
    const handelAdd=(e)=>{
        e.preventDefault()
        let obj={
            id:Date.now(),
            name:name,
            height:height,
            weight:weight,
            power:power
        }
        setData(data.concat(obj))
        // setActual(actual.concat(obj))
      
        
    }
     
   const handelPower=()=>{
     let max=data.reduce((p, c) => p.power > c.power ? p : c)
     setActual(actual.concat(max))
     setState(true)
   }

    const handelShowAll=()=>{
     setState(false)
    }
console.log(actual)
       
        // var b=document.getElementById("b").innerText=null
        // var c=document.getElementById("c").innerText=null
        // var d=document.getElementById("d").innerText=null
    // useEffect(()=>{
    //   handelAdd()
    // },[name,height,weight,power])


    return(
        <>
        <form>
            <input data-testid="input-name" type="text"   onChange={handleName}     id="a" placeholder="name"  />
            <input data-testid="input-height" type="number" onChange={handleHeight} id="b" placeholder="height" />
            <input data-testid="input-weight" type="number" onChange={handleWeight} id="c" placeholder="weight" />
            <input data-testid="input-power" type="number"  onChange={handlePower}  id="d" placeholder="power"  /> 
            <button data-testid="add-button" onClick={handelAdd} disabled={name===""} >Add SuperHero</button>
        </form>
        <button data-testid="most-powerfull"  onClick={handelPower}>Most Powerful Superhero</button>
        <button data-testid="all-superheroes" onClick={handelShowAll}>Show All</button>
        <Card data={state===true?actual:data}/>
        </>
    )
}

export default InputTags;

// disabled={name==="" && height===0 && weight===0 && power===0 && power>10}