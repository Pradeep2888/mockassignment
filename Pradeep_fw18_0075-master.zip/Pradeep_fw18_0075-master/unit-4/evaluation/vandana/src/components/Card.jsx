const Card=({data=data})=>{
    // const {name,weight,height,power}=data
    // console.log(data)
    return (
        <div data-testid="data-list">
            {data.map((item)=>{
                return(
                    <div data-testid="superhero-list">
                        {/*All the content of the card has to be added over here*/}
                        <h2>HeroName:{item.name}</h2>
                        <h3>Height:{item.height}</h3>
                        <h3>Weight:{item.weight}</h3>
                        <h3>Power Level:{item.power}</h3>
                    </div>
                )
            })}
        </div>
    )
}

export default Card;
