import InputTags from './components/InputTags';
import './App.css';

function App() {

  return (
      <div className="App">
        <InputTags/>
      </div>
  );
}

export default App;
