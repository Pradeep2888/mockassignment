import React, { useEffect, useState } from "react";
import EmployeeName from "./EmployeeName";
import EmployeeSalary from "./EmployeeSalary";


const top=[
  {
      "id": 32,
      "name": "Nev Tinston",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Product Management",
      "gender": "male",
      "salary": 10000
  },
  {
      "id": 47,
      "name": "Julian Woollam",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Product Management",
      "gender": "others",
      "salary": 10000
  },
  {
      "id": 4,
      "name": "Benji Knapman",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Research and Development",
      "gender": "male",
      "salary": 15000
  },
  {
      "id": 39,
      "name": "Carlynn Joncic",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Engineering",
      "gender": "male",
      "salary": 15000
  },
  {
      "id": 52,
      "name": "Verene Grice",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Training",
      "gender": "others",
      "salary": 15000
  },
  {
      "id": 2,
      "name": "Flossy Arrell",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Product Management",
      "gender": "others",
      "salary": 20000
  },
  {
      "id": 26,
      "name": "Korry Champken",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Research and Development",
      "gender": "female",
      "salary": 20000
  },
  {
      "id": 40,
      "name": "Anselma Dybald",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Training",
      "gender": "female",
      "salary": 20000
  },
  {
      "id": 60,
      "name": "Ciel Taree",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Legal",
      "gender": "male",
      "salary": 20000
  },
  {
      "id": 68,
      "name": "Colly Kernoghan",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Engineering",
      "gender": "others",
      "salary": 20000
  }
]
const bottom=[
  {
      "id": 62,
      "name": "Corey Whitsun",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Engineering",
      "gender": "others",
      "salary": 150000
  },
  {
      "id": 9,
      "name": "Nevile Logan",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Support",
      "gender": "female",
      "salary": 145000
  },
  {
      "id": 12,
      "name": "Udall Boston",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Business Development",
      "gender": "male",
      "salary": 145000
  },
  {
      "id": 27,
      "name": "Vale Fenny",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Services",
      "gender": "male",
      "salary": 145000
  },
  {
      "id": 59,
      "name": "Timmie Paulino",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Marketing",
      "gender": "male",
      "salary": 145000
  },
  {
      "id": 6,
      "name": "Leonora Pachmann",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Training",
      "gender": "male",
      "salary": 140000
  },
  {
      "id": 14,
      "name": "Dene Teenan",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Services",
      "gender": "female",
      "salary": 130000
  },
  {
      "id": 25,
      "name": "Belinda Renzini",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Training",
      "gender": "others",
      "salary": 130000
  },
  {
      "id": 37,
      "name": "Brendan Cutill",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Sales",
      "gender": "male",
      "salary": 130000
  },
  {
      "id": 43,
      "name": "Akim Jaher",
      "image": "https://imgur.com/9xEcfJj",
      "department": "Services",
      "gender": "male",
      "salary": 130000
  }
]

// const bottom=


export const Dashboard = () => {
const [data,setData]=useState([])
const [status,setStatus]=useState(true)
// const [top,setTop]=useState([])
// const [bottom,setBottom]=useState([])
const getData=async()=>{
try{
let res1=await fetch(`https://dbioz2ek0e.execute-api.ap-south-1.amazonaws.com/mockapi/get-employees?page=1`)
let res2=await fetch(`https://dbioz2ek0e.execute-api.ap-south-1.amazonaws.com/mockapi/get-employees?page=2`)
let res3=await fetch(`https://dbioz2ek0e.execute-api.ap-south-1.amazonaws.com/mockapi/get-employees?page=3`)
let res4=await fetch(`https://dbioz2ek0e.execute-api.ap-south-1.amazonaws.com/mockapi/get-employees?page=4`)
let res5=await fetch(`https://dbioz2ek0e.execute-api.ap-south-1.amazonaws.com/mockapi/get-employees?page=5`)
let res6=await fetch(`https://dbioz2ek0e.execute-api.ap-south-1.amazonaws.com/mockapi/get-employees?page=6`)
let res7=await fetch(`https://dbioz2ek0e.execute-api.ap-south-1.amazonaws.com/mockapi/get-employees?page=7`)
let dat1=await res1.json()
let dat2=await res2.json()
let dat3=await res3.json()
let dat4=await res4.json()
let dat5=await res5.json()
let dat6=await res6.json()
let dat7=await res7.json()
// Promise.all([dat1.data,dat2.data,dat3.data,dat4.data,dat5.data,dat6.data,dat7.data]).then((values) => {
  // console.log(dat1);
// });
Array.prototype.push.apply(dat1.data,dat2.data); 
Array.prototype.push.apply(dat1.data,dat3.data); 
Array.prototype.push.apply(dat1.data,dat4.data); 
Array.prototype.push.apply(dat1.data,dat5.data); 
Array.prototype.push.apply(dat1.data,dat6.data); 
Array.prototype.push.apply(dat1.data,dat7.data); 
setData(dat1.data)
}
catch(err){
  console.log(err)
}
}

const handelClick=()=>{
 setStatus(!status)
  if(status===true){
    data.sort((a,b)=>a.salary-b.salary)
    // setTop(data)
    // console.log(top)
    // status(false)
    // setData(top)
  }
  else if(status===false){
    data.sort((a,b)=>b.salary-a.salary)
    // setBottom(data)
    // setData(bottom)
  }

  // let a=data.slice(0, 10)
  // setTop(a)
  // console.log(a)

}


// console.log(status)
useEffect(()=>{
getData()
},[])
  return (
    <div>
      <button
        data-testid="sorting-btn"
        onClick={handelClick}
      >
       {status===true?"Bottom 10 Employees":"Top 10 Employees"}
      </button>

      {
      /* <div data-testid="employee-data">
        {
          data.slice(0, 10).map((item,index)=>( 
            
            <div data-testid="employee-name"> {item.name} </div>
            

          ))
        }
        {
          data.slice(0, 10).map((item,index)=>( 
           
            <div data-testid="employee-salary"> {item.salary} </div>

          ))
        }
        
        
      </div>
  */}
      {
        data.slice(0,10).map((item)=>(
          <div data-testid="employee-data">
        {
          data.slice(0, 10).map((item,index)=>( 
            
            <div data-testid="employee-name"> {item.name} </div>
            

          ))
        }
        {
          data.slice(0, 10).map((item,index)=>( 
           
            <div data-testid="employee-salary"> {item.salary} </div>

          ))
        }
        
        
      </div>
        ))
      }

      {/* wdsdfsdf */}
      
    </div>
  );
};
