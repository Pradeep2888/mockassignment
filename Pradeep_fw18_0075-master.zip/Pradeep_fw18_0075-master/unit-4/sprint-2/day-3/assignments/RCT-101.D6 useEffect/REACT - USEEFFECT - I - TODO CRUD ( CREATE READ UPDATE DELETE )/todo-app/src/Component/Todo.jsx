import React, { useEffect } from 'react'
import { useState } from 'react'

function Todo() {
    const [text,setText]=useState("")
    const [data,setData]=useState([])
    const [page,setPage]=useState(1)
    
    const handelChange=(e)=>{
        setText(e.target.value)
    }
    const handelAdd=async ()=>{
       let obj={
        id:Date.now()+text,
        title:text,
        status:false
       }

       let res=await fetch(`http://localhost:5010/todo`,{
        method:'POST',
        body:JSON.stringify(obj),
        headers:{'Content-Type':'application/json'}
       })
       let data=await res.json()
       
    }
    const handelStatus=async(id,status1)=>{
        let change
          {status1===true?change=false:change=true}
        let res=await fetch(`http://localhost:5010/todo/${id}`,{
            method:'PATCH',
            body:JSON.stringify({
                status:change
            }),
            headers:{'Content-Type':'application/json'}
           })
           let data=await res.json()
        // console.log(change,id)
    }
    const handelDelete=async(id)=>{
        let res=await fetch(`http://localhost:5010/todo/${id}`,{
            method:'DELETE',
            headers:{'Content-Type':'application/json'}
           })
           let data=await res.json()
           
    }
    async function getData(){
        try{
         let res=await fetch(`http://localhost:5010/todo?_page=${page}&_limit=5`)
        let data=await res.json()
         setData(data)
        }
        catch(err){
            console.log(err)
        }
    }
    console.log(data)
    useEffect(()=>{
  getData()
    },[page])
    // useEffect
  return (
    <div>
        <h1>Todo app</h1>
        <input onChange={handelChange}></input>
        <button onClick={handelAdd}>Add</button>
        {/* <button onClick={getData}>Fetch Data</button> */}
        <ul>
            {
                data.map((item)=>(<li key={item.id}>{`${item.title} --${item.status} `}<button onClick={({id,status})=>handelStatus(item.id,item.status)}>Change Status</button> <button onClick={({id})=>handelDelete(item.id)}>Delete</button></li>))
            }
        </ul>
        <button disabled={page===1} onClick={()=>setPage(page-1)}>Pre</button>
        <h3>{page}</h3>
        <button disabled={data.length===0} onClick={()=>setPage(page+1)}>Next</button>
    </div>
  )
}

export default Todo