there should matrix of 3*3 on every input there should change of player and if any dignol or side should be matched with same type of input that player should be winner




