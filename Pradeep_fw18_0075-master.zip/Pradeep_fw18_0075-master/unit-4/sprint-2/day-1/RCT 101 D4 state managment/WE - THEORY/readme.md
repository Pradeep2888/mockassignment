Q1.what is the difference between Props and State?
Ans:props are the properties which are import and export from one file to anoter file
and state are lite variable which are update on any call of function

Q2.Explain the useState API?
Ans:useState is a hood of react which include one variable and one fonction which will update call function

Q3.Explain the how map, filter, reduce work 
Ans:map is higer order function which return something 
filter is inbuilt function which identify perticular element and exclude it from arr

Q4.?