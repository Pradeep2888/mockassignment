

import React from 'react'

function TodoItem({status,title,id,handelToggle}) {
  // console.log(id)
  return (
    <div style={{display:"flex" , justifyContent:"space-between"}}>
      <div>{id}</div>
      <div>{title}</div>
      <div>Completed: {!status?"Not Done":"Done"}</div>
      <div><button onClick={()=>handelToggle(id)}>Toogle to Complete</button></div>

    </div>
  )
}

export default TodoItem