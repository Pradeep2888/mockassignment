import React, { useState } from 'react'
import { useEffect } from 'react'
import TodoList from './TodoList'

function Todo() {
const [data,setData]=useState([])

function handelToggle(id){
  console.log(id)
 const updateData=data.map((item)=>
 item.id===id?{...item,completed:!item.completed}:item
 )
 console.log(updateData)
 setData(updateData)
    }



useEffect(()=>{
    async function getTodos(){
        try{
            let res=await fetch("https://jsonplaceholder.typicode.com/todos")
            let dat=await res.json()
            setData(dat)
            }
            catch(err){
             console.log(err)
            }

    }
    getTodos()
},[])

  return (
    <div>
        <h1>Todoes List</h1>
        <TodoList data={data}   handelToggle={handelToggle}/>
    </div>
  )
}

export default Todo