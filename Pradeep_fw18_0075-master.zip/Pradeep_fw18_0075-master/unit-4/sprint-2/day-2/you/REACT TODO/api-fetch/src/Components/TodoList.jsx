import TodoItem from './TodoItem'

import React from 'react'


function TodoList({data,handelToggle}) {



//     appendData()

// function appendData(){
//   data.map((item)=>{
//     console.log(item.id)
//   })
// }
  return (
    <div>
      {data.map((item)=>(
        <TodoItem
        id={item.id}
        status={item.completed}
        title={item.title}
        handelToggle={handelToggle}
        />
      ))}
       
    </div>
  )
}

export default TodoList