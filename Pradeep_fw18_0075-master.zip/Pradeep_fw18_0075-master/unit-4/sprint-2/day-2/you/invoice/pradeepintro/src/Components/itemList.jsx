import TodoItem from "./TodoItem"





function ItemList({data, handelIncrement,handelDecrement}){



    
   

return(
    <div style={{border:"1px solid red"}}>
       {data.map(item=>(
        <TodoItem
        id={item.id}
        price={item.price}
        product_name={item. product_name}
        quantity={item.quantity}
        handelIncrement={ handelIncrement}
        handelDecrement={ handelDecrement}
        />
       ))} 

      
    </div>
    
)
}


export default ItemList