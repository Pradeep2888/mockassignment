import logo from './logo.svg';
import './App.css';
import Cart from "./Components/Cart.js"

function App() {
  return (
    <div className="App">
      <h1>INVOICE</h1>
      <Cart/>
    </div>
  );
}

export default App;
