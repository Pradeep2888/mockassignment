import React, { useState } from "react"

import ItemList from "./itemList"


const data=[
    {
        id:"1",
        product_name:"pizza",
        price:100,
        quantity:1
    },
    {
        id:"2",
        product_name:"pizza",
        price:200,
        quantity:2
    },
    {
        id:"3",
        product_name:"pizza",
        price:300,
        quantity:3
    }
]

function Cart(){

const [data1,setData]=useState(data)

   function handelIncrement(id){
    
   let arr= data1.map((el)=>{
        if(el.id===id ){
            el.quantity=el.quantity+1

         return el;
        }
        else {
            return el;
        }
    })
    setData(arr)
    console.log(arr)
   }

   function handelDecrement(id){
    let arr=data.map((el)=>{
        if(el.id===id && el.quantity>0){
            el.quantity=el.quantity-1
            return el;

        }
        else{
            return el;

        }
    })
    setData(arr)
   }

   function handelTotal(data){
   return data.reduce((acc,c)=>acc+(c.quantity*c.price),0)
   

   }
  

    return (
        <div  style={{border:"10px solid red" ,height:"400px",width:"400px",margin:"auto"}}>
        <div  > 
           <ItemList 
           data={data1}
           handelIncrement={ handelIncrement}
           handelDecrement={ handelDecrement}
       
           />
        </div>
        <div>
     
      <h2>Total:{ handelTotal(data)}</h2>
      
       </div>

        </div>
    )
}

export default Cart