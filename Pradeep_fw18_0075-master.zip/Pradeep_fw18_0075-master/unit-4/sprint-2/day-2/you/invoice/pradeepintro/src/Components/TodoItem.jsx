function TodoItem({id,price,product_name,quantity,handelIncrement,handelDecrement}){
    // console.log(id)
    return(
        <div style={{display:"flex" , justifyContent:"space-between", border:"1px solid red"}}>
        <div><h4>{product_name}</h4></div>
        <div><h4>{price}</h4></div>
        <div style={{display:"flex",alignItems:"center" }}>
            <div> <button onClick={()=>handelDecrement(id)} >-</button></div>
            <div><h4>{quantity}</h4></div>
            <div><button  onClick={()=>handelIncrement(id)}>+</button></div>
           </div>
        
        </div>
    )
}

export default TodoItem