import logo from './logo.svg';
import './App.css';
import Invoice from './Component/Invoice';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Invoice/>
      </header>
    </div>
  );
}

export default App;
