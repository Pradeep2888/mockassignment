import React from 'react'
import { useState } from 'react'
import { useEffect } from 'react'
import "./Invoice.css"

function Invoice() {
    const [qty1,setQty1]=useState(0)
    const [qty2,setQty2]=useState(0)
    const [qty3,setQty3]=useState(0)
    const [total,setTotal]=useState(0)

   
  return (
    <div>
       <div className='body'>
         <h1>Invoice</h1>
        {/* card1 */}
        <div id='card1'>
            <h3>Noodes</h3>
            <h3>30/-</h3>
            <button onClick={()=>setQty1(qty1+1)} id='button'>+</button>
            <h2>{qty1}</h2>
            <button disabled={qty1===0} onClick={()=>setQty1(qty1-1)}>--</button>
        </div>

        {/* card2 */}
        <div id='card2'>
            <h3>Biriyani</h3>
            <h3>90/-</h3>
            <button onClick={()=>setQty2(qty2+1)} id='button'>+</button>
            <h2>{qty2}</h2>
            <button disabled={qty2===0} onClick={()=>setQty2(qty2-1)}>--</button>
        </div>

        {/* card3 */}
        <div id='card3'>
           <h3>Chips</h3>
           <h3>10/-</h3>
           <button onClick={()=>setQty3(qty3+1)} id='button'>+</button>
            <h2>{qty3}</h2>
            <button disabled={qty3===0} onClick={()=>setQty3(qty3-1)}>--</button>
        </div>

        {/* card4 */}

        <div>
            <h3>Total=</h3>
            <h3>{qty1*30+qty2*90+qty3*10}/-</h3>
        </div>
       </div>
    </div>
  )
}

export default Invoice