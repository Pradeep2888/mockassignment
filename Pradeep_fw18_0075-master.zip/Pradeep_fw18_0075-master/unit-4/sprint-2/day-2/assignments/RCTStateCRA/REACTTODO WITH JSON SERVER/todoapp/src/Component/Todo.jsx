import React from 'react'
import { useState } from 'react'

function Todo() {
    const [text,setText]=useState("")
    const [data,setData]=useState([])
    
    const handelChange=(e)=>{
        setText(e.target.value)
    }
    const handelAdd=async ()=>{
       let obj={
        id:Date.now()+text,
        title:text,
        status:false
       }

       let res=await fetch(`http://localhost:5010/todo`,{
        method:'POST',
        body:JSON.stringify(obj),
        headers:{'Content-Type':'application/json'}
       })
       let data=await res.json()
       
    }
    async function getData(){
        try{
         let res=await fetch(`http://localhost:5010/todo`)
        let data=await res.json()
         setData(data)
        }
        catch(err){
            console.log(err)
        }
    }
    console.log(data)
  return (
    <div>
        <h1>Todo app</h1>
        <input onChange={handelChange}></input>
        <button onClick={handelAdd}>Add</button>
        <button onClick={getData}>Fetch Data</button>
        
            {
                data.map((item)=>(<li>{item.title}</li>))
            }
        
    </div>
  )
}

export default Todo