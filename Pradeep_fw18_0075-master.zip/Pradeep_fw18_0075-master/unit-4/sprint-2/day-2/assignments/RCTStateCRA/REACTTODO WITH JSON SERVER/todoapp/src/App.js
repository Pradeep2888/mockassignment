import logo from './logo.svg';
import './App.css';
import Todo from './Component/Todo';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Todo/>
      </header>
    </div>
  );
}

export default App;
