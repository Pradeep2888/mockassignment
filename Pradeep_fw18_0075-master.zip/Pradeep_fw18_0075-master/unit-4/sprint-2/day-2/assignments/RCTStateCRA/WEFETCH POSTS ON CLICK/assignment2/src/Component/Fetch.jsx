import React from 'react'
import { useState } from 'react'

function Fetch() {
const [data,setData]=useState([])

async function getData(){
    try{
       let res=await fetch(`https://jsonplaceholder.typicode.com/posts`)
       let data=await res.json()
       setData(data)
    }
    catch(err){
        console.log(err)
    }
}

const handelClick=()=>{
    getData()
    
}
console.log(data)


  return (
    <div>
        <button onClick={handelClick}>Fetch data</button>
        <ul>
            {
                data.map((item)=>(
                    <li>{item.title}</li>
                ))
            }
        </ul>
    </div>
  )
}

export default Fetch