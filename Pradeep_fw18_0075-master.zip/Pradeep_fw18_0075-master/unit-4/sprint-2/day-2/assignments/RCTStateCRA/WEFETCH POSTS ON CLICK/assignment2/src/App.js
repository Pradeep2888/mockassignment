import logo from './logo.svg';
import './App.css';
import Fetch from './Component/Fetch';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <Fetch/>
      </header>
    </div>
  );
}

export default App;
